

package com.mycompany.wordguessinggame;

import java.util.ArrayList;
import java.util.Scanner;

public class WordGuessingGame {

    public static void main(String[] args) {
        // Scanner object for user input
        Scanner input = new Scanner(System.in);
        // ArrayList to store words and scores
        ArrayList<String> words = new ArrayList<>();
        ArrayList<String> scores_list = new ArrayList<>();
        // Variable to track the number of attempts in the game
        int attempts = 0;
        // Infinite loop for the main menu      
        while (true) {
            // Display the menu
            Menu();
            
            // User input for menu choice
            int choice = input.nextInt();
           
            // Switch statement for menu choices
            switch (choice) {
                case 1:
                    addWord(input, words); // method for adding a new word to the list
                    break;
                case 2:
                   NewGame(input, words, attempts, scores_list); // Start a new game method
                    break;
                case 3:
                    Scores(scores_list); // Display scores method
                    break;
                case 4:
                    System.out.println("Exiting the game. Goodbye!");
                    input.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
            }
        }
    }

    public static void Menu() {  // Display the menu options
        System.out.println("Main Menu:");
        System.out.println("1. Add New Word");
        System.out.println("2. New Game");
        System.out.println("3. Show Scores");
        System.out.println("4. Exit");
        System.out.print("enter your choice: ");
    }

   public static void Scores(ArrayList<String> scores_list) {  // Display the scores stored in the scores_list ArrayList
    System.out.println("Scores: ");
    if (scores_list.size() != 0) { // Check if scores_list is not empty
        for (int i = 0; i < scores_list.size(); i++) {
            System.out.println(scores_list.get(i )); // Display the entries in the scores_list
        }
         // Display the last entry in the scores_list
    
    } else {
        
        System.out.println("No scores available.");
    }
}

    public static void addWord(Scanner input, ArrayList<String> words) { // Add a new word to the words ArrayList with certain conditions
        System.out.print("Enter a new word: ");
        String newWord = input.next();

        boolean word = true; 
        for (int i = 0; i < newWord.length(); i++) { // Check if the newWord is a valid word
            char c = newWord.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {
                word = false;
            }
        }

        if (word && newWord.length() >= 4 && !words.contains(newWord)) { // Check conditions for a valid word and add it to the list
            if (!words.contains(newWord)) {
                words.add(newWord);
                System.out.println("Word added successfully!");
            } else {  // Check if the word is not already in the list, then add it and provide feedback
                System.out.println("You entered this word before. Try a different one.");
            }
        } else {
            System.out.println("Invalid word. Please check the conditions.");
        }

    }
     // Start a new word-guessing game
    public static void NewGame(Scanner input, ArrayList<String> words, int attempts, ArrayList<String> scores_list) {
        if (words.size() == 0) { // Check if there are words available for the game
            System.out.println("No words available. Add words before starting a new game.");
            return;
        }

        String selectedWord = words.get((int) (Math.random() * words.size())); // Select a random word for the game
        attempts = selectedWord.length() / 2;  // make attempts the half of the lenght of random word
        String guessedWord = repeatingChar('_', selectedWord.length()); // Initialize the guessedWord with underscores
        int points = 0;
        
        while (attempts > 0 && guessedWord.contains("_")) { // Main game loop
            System.out.println("Current word: " + guessedWord);
            System.out.println("Attempts left: " + attempts);

            char guess = getGuess(input);

           if (selectedWord.contains(String.valueOf(guess))) { // Check if the guessed letter is in the selected word
                if (!guessedWord.contains(String.valueOf(guess))) {
                    int multiple = 0;
                    for (int i = 0; i < selectedWord.length(); i++) { // to show how much of the guessed letter in the selected word
                        if (selectedWord.charAt(i) == guess) {
                            multiple++;
                        }
                    }
                    System.out.println("There is " + multiple + "\'" + guess + "\'");
                    guessedWord = UpdateGuessingWord(selectedWord, guessedWord, guess);
                    System.out.println(guessedWord);
                } else {
                    System.out.println("You entered this letter before. Try a different one.");
                }
            } else {
                System.out.println("There is not \"" + guess + "\"");
                attempts--;
            }
             // Display an empty line for better readability
            System.out.println();
    }
        displayGameResult(guessedWord, selectedWord, attempts, points, scores_list); // Display the result of the word-guessing game
  }
    public static char getGuess(Scanner input) { // Get user's guess for the game
        System.out.print("Enter your guess: ");
        return input.next().charAt(0);
    }

    public static String repeatingChar(char character, int count) { // Create a String with repeated characters
        char[] repeatedChars = new char[count];
        for (int i = 0; i < count; i++) {
            repeatedChars[i] = character;
        }
        return new String(repeatedChars);
    }

   public static String UpdateGuessingWord(String word, String GuessingWord, char letter) { // Update the guessedWord with the correctly guessed letter
    char[] updatedWord = new char[GuessingWord.length()];
    for (int i = 0; i < word.length(); i++) {
        if (word.charAt(i) == letter) {
            updatedWord[i] = letter;
        } else {
            updatedWord[i] = GuessingWord.charAt(i);
        }
    }
    return new String(updatedWord);
}
   // Display the result of the word-guessing game
    public static void displayGameResult(String guessedWord, String selectedWord, int attempts, int points, ArrayList<String> scores_list) {
    if (guessedWord.contains("_") && attempts == 0) {
        System.out.println("Sorry, you ran out of attempts. The correct word was: " + selectedWord);
        scores_list.add("Game Over");
    } else if (!guessedWord.contains("_")) {
        // Calculate points for each correct letter
        for (int i = 0; i < selectedWord.length(); i++) {
            if (selectedWord.charAt(i) == guessedWord.charAt(i)) {
                points += 2; // 2 points for each correct letter
            }
        }

        System.out.println("Congratulations! You guessed the word: " + selectedWord);
        System.out.println("Points earned: " + points);
        scores_list.add("score: " + points);
    }
}
}
