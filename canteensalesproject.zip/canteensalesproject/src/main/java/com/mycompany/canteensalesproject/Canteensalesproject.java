/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.canteensalesproject;

/**
 *
 * @author a
 */
public class Canteensalesproject {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
