#include <stdlib.h> 
#include <string.h> 
#include <stdio.h>  
#include "../include/material.h" 

// Function to create and initialize a new material
MaterialType* create_material(const char* name, float weight, int quantity) {
    MaterialType* material = malloc(sizeof(MaterialType)); // Allocate memory for a new material
    if (!material) return NULL; // Return NULL if memory allocation fails
    
    strncpy(material->name, name, 49); // Copy material name (max 49 characters to avoid overflow)
    material->name[49] = '\0'; // Ensure the name is null-terminated
    material->weight = weight; // Set material weight
    material->quantity = quantity; // Set total quantity of the material
    material->loaded = 0; // Initialize loaded quantity to 0
    
    return material; // Return pointer to the new material
}

// Function to update material quantity during loading/unloading
void update_material_quantity(MaterialType* material, int change, int is_loading) {
    if (is_loading) { // If loading, increase the loaded quantity
        material->loaded += change;
    } else { // If unloading, decrease the loaded quantity
        material->loaded -= change;
    }
}

// Function to display the status of all materials
void display_materials_status(MaterialType** materials, int count) {
    printf("\n=== Materials Status ===\n");
    for (int i = 0; i < count; i++) { // Loop through all materials
        printf("%s:\n", materials[i]->name); // Display material name
        printf("  Total quantity: %d\n", materials[i]->quantity); // Display total quantity
        printf("  Loaded on train: %d\n", materials[i]->loaded); // Display loaded quantity
        printf("  Available: %d\n", materials[i]->quantity - materials[i]->loaded); // Display available quantity
    }
}
