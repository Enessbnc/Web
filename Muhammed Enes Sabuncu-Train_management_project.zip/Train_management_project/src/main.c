#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include "../include/train.h" 
#include "../include/material.h" 
#include "../include/file_ops.h" 
#include "../include/utils.h" 

#define MAX_MATERIALS 3 // Maximum number of material types allowed
#define DEFAULT_SAVE_FILE "train_status.txt" // Default file for saving train status

// Function to display the main menu options
void display_menu() {
    printf("\n=== Train Loading Management System ===\n");
    printf("1. Load train status from file\n");
    printf("2. Load material, starting from first suitable wagon\n");
    printf("3. Load material to specific wagon\n");
    printf("4. Unload material, starting from tail\n");
    printf("5. Unload material from specific wagon\n");
    printf("6. Display train status\n");
    printf("7. Display materials status\n");
    printf("8. Empty train\n");
    printf("9. Save train status to file\n");
    printf("10. Exit\n");
    printf("Enter your choice: ");
}

// Function to display the available materials and their statuses
void display_materials_menu(MaterialType** materials, int count) {
    printf("\nAvailable Materials:\n");
    for (int i = 0; i < count; i++) {
        printf("%d. %s (%.2f kg) - Available: %d\n", 
               i + 1, // Display material index starting from 1
               materials[i]->name, // Material name
               materials[i]->weight, // Material weight
               materials[i]->quantity - materials[i]->loaded); // Available quantity
    }
}

// Main function
int main() {
    Train* train = create_train("T123"); // Initialize train with ID "T123"
    MaterialType* materials[MAX_MATERIALS]; // Array to store material types
    
    // Initialize materials with predefined names, weights, and quantities
    materials[0] = create_material("Large Box", 200.0, 50);
    materials[1] = create_material("Medium Box", 150.0, 50);
    materials[2] = create_material("Small Box", 100.0, 50);
    
    int choice; // Variable to store user menu choice
    char filename[256]; // Buffer for file name input
    
    do {
        display_menu(); // Display menu options
        scanf("%d", &choice); // Get user choice
        clear_input_buffer(); // Clear input buffer for safety
        
        int material_index, quantity, wagon_id; // Variables for user input
        
        switch (choice) {
            case 1:
                printf("Enter filename (or press Enter for default '%s'): ", DEFAULT_SAVE_FILE);
                fgets(filename, sizeof(filename), stdin); // Get filename from user
                filename[strcspn(filename, "\n")] = 0; // Remove trailing newline
                
                if (strlen(filename) == 0) {
                    strcpy(filename, DEFAULT_SAVE_FILE); // Use default file if no input
                }
                
                if (load_train_status(filename, train, materials, MAX_MATERIALS)) {
                    printf("Train status loaded successfully from %s\n", filename);
                } else {
                    printf("Error loading train status from %s\n", filename);
                }
                break;
                
            case 2:
                display_materials_menu(materials, MAX_MATERIALS); // Show materials menu
                printf("Select material (1-%d): ", MAX_MATERIALS);
                scanf("%d", &material_index);
                material_index--; // Convert 1-based index to 0-based
                
                if (material_index >= 0 && material_index < MAX_MATERIALS) {
                    int available = materials[material_index]->quantity - 
                                  materials[material_index]->loaded; // Calculate available quantity
                    
                    if (available > 0) {
                        printf("Enter quantity (max %d): ", available);
                        scanf("%d", &quantity);
                        quantity = validate_quantity(quantity, available); // Validate input quantity
                        
                        load_material(train, materials[material_index], quantity); // Load material
                    } else {
                        printf("No %s available to load\n", materials[material_index]->name);
                    }
                } else {
                    printf("Invalid material selection\n");
                }
                break;
                
            case 3:
                printf("Enter wagon ID: ");
                scanf("%d", &wagon_id); // Get wagon ID from user
                
                // Find wagon by ID to validate existence
                Wagon* target_wagon = train->first_wagon;
                while (target_wagon && target_wagon->wagon_id != wagon_id) {
                    target_wagon = target_wagon->next;
                }
                
                if (!target_wagon) {
                    printf("Wagon %d not found\n", wagon_id);
                    break;
                }
                
                display_materials_menu(materials, MAX_MATERIALS); // Show materials menu
                printf("Select material (1-%d): ", MAX_MATERIALS);
                scanf("%d", &material_index);
                material_index--;
                
                if (material_index >= 0 && material_index < MAX_MATERIALS) {
                    int available = materials[material_index]->quantity - 
                                  materials[material_index]->loaded; // Calculate available quantity
                    
                    if (available > 0) {
                        printf("Enter quantity (max %d): ", available);
                        scanf("%d", &quantity);
                        quantity = validate_quantity(quantity, available); // Validate input quantity
                        
                        load_material_to_wagon(train, wagon_id, materials[material_index], quantity); // Load material to specific wagon
                    } else {
                        printf("No %s available to load\n", materials[material_index]->name);
                    }
                } else {
                    printf("Invalid material selection\n");
                }
                break;
                
            case 4:
                display_materials_menu(materials, MAX_MATERIALS); // Show materials menu
                printf("Select material to unload (1-%d): ", MAX_MATERIALS);
                scanf("%d", &material_index);
                material_index--;
                
                if (material_index >= 0 && material_index < MAX_MATERIALS) {
                    if (materials[material_index]->loaded > 0) { // Check if material is loaded
                        printf("Enter quantity (max %d): ", materials[material_index]->loaded);
                        scanf("%d", &quantity);
                        quantity = validate_quantity(quantity, materials[material_index]->loaded); // Validate input quantity
                        
                        unload_material(train, materials[material_index], quantity); // Unload material
                        renumber_wagons(train); // Renumber wagons after unloading
                    } else {
                        printf("No %s loaded on train\n", materials[material_index]->name);
                    }
                } else {
                    printf("Invalid material selection\n");
                }
                break;
                
            case 5:
                printf("Enter wagon ID: ");
                scanf("%d", &wagon_id); // Get wagon ID from user
                display_materials_menu(materials, MAX_MATERIALS); // Show materials menu
                printf("Select material to unload (1-%d): ", MAX_MATERIALS);
                scanf("%d", &material_index);
                material_index--;
                
                if (material_index >= 0 && material_index < MAX_MATERIALS) {
                    printf("Enter quantity: ");
                    scanf("%d", &quantity); // Get quantity to unload
                    
                    unload_material_from_wagon(train, wagon_id, materials[material_index], quantity); // Unload material from specific wagon
                    renumber_wagons(train); // Renumber wagons after unloading
                } else {
                    printf("Invalid material selection\n");
                }
                break;
                
            case 6:
                display_train_status(train); // Display train status
                break;
                
            case 7:
                display_materials_status(materials, MAX_MATERIALS); // Display materials status
                break;
                
            case 8:
                empty_train(train); // Empty all wagons in the train
                // Reset loaded counts for materials
                for (int i = 0; i < MAX_MATERIALS; i++) {
                    materials[i]->loaded = 0;
                }
                printf("Train emptied successfully\n");
                break;
                
            case 9:
                printf("Enter filename (or press Enter for default '%s'): ", DEFAULT_SAVE_FILE);
                fgets(filename, sizeof(filename), stdin); // Get filename from user
                filename[strcspn(filename, "\n")] = 0; // Remove trailing newline
                
                if (strlen(filename) == 0) {
                    strcpy(filename, DEFAULT_SAVE_FILE); // Use default file if no input
                }
                
                if (save_train_status(filename, train, materials, MAX_MATERIALS)) {
                    printf("Train status saved successfully to %s\n", filename);
                } else {
                    printf("Error saving train status to %s\n", filename);
                }
                break;
                
            case 10:
                printf("Saving final state to %s...\n", DEFAULT_SAVE_FILE);
                if (save_train_status(DEFAULT_SAVE_FILE, train, materials, MAX_MATERIALS)) {
                    printf("Final state saved successfully\n");
                } else {
                    printf("Warning: Could not save final state\n");
                }
                printf("Exiting program...\n");
                break;
                
            default:
                printf("Invalid choice! Please select a number between 1 and 10.\n");
        }
        
        printf("\n");  // Add a newline for better readability between operations
        
    } while (choice != 10); // Repeat until user chooses to exit
    
    // Cleanup before exit
    for (int i = 0; i < MAX_MATERIALS; i++) {
        free(materials[i]); // Free allocated memory for materials
    }
    free_train(train); // Free allocated memory for train
    
    return 0; 
}
