#include <stdio.h>  
#include <string.h> 
#include <ctype.h>  
#include "../include/utils.h" 

// Function to clear the input buffer
void clear_input_buffer(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF); // Consume characters until newline or EOF
}

// Function to find a material by name in an array of materials
MaterialType* find_material_by_name(MaterialType** materials, int count, const char* name) {
    for (int i = 0; i < count; i++) { // Loop through all materials
        if (strcmp(materials[i]->name, name) == 0) { // Compare material name
            return materials[i]; // Return the matching material
        }
    }
    return NULL; // Return NULL if no match is found
}

// Function to validate the quantity of materials to be loaded/unloaded
int validate_quantity(int requested, int available) {
    if (requested <= 0) return 0; // Invalid if requested is less than or equal to 0
    if (requested > available) return available; // Limit to the available quantity
    return requested; // Return the requested quantity if valid
}

// Function to renumber wagons in a train sequentially starting from 1
void renumber_wagons(Train* train) {
    int new_id = 1; // Start IDs from 1
    Wagon* current = train->first_wagon; // Start from the first wagon
    while (current) { // Loop through all wagons
        current->wagon_id = new_id++; // Assign a new ID and increment
        current = current->next; // Move to the next wagon
    }
}

// Function to trim leading and trailing spaces from a string
char* trim_string(char* str) {
    char* end;

    // Trim leading spaces
    while (isspace((unsigned char)*str)) str++; // Move the pointer past leading spaces

    if (*str == 0) return str; // Return if the string is empty

    // Trim trailing spaces
    end = str + strlen(str) - 1; // Point to the last character
    while (end > str && isspace((unsigned char)*end)) end--; // Move back past trailing spaces

    end[1] = '\0'; // Null-terminate the string
    return str; // Return the trimmed string
}
