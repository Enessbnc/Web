#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include "../include/file_ops.h" 
#include "../include/utils.h" 

// Function to save the train's status to a file
int save_train_status(const char* filename, Train* train, MaterialType** materials, int material_count) {
    FILE* file = fopen(filename, "w"); // Open file for writing
    if (!file) return 0; // Return 0 if file cannot be opened
    
    // Write train details (ID and number of wagons)
    fprintf(file, "TRAIN:%s:%d\n", train->train_id, train->wagon_count);
    
    // Write materials section header
    fprintf(file, "\nMATERIALS:%d\n", material_count);
    for (int i = 0; i < material_count; i++) { // Loop through all materials
        fprintf(file, "M:%s:%.2f:%d:%d\n", // Write material details
                materials[i]->name,
                materials[i]->weight,
                materials[i]->quantity,
                materials[i]->loaded);
    }
    
    // Write wagons section
    Wagon* current_wagon = train->first_wagon;
    while (current_wagon) { // Loop through all wagons
        fprintf(file, "\nWAGON:%d:%.2f:%.2f\n", // Write wagon details
                current_wagon->wagon_id,
                current_wagon->max_weight,
                current_wagon->current_weight);
        
        // Write loaded materials in the current wagon
        LoadedMaterial* loaded = current_wagon->loaded_materials;
        while (loaded) { // Loop through loaded materials
            fprintf(file, "L:%s\n", loaded->type->name); // Write loaded material name
            loaded = loaded->next; // Move to the next loaded material
        }
        
        current_wagon = current_wagon->next; // Move to the next wagon
    }
    
    fclose(file); // Close the file
    return 1; // Return success
}

// Function to load the train's status from a file
int load_train_status(const char* filename, Train* train, MaterialType** materials, int material_count) {
    FILE* file = fopen(filename, "r"); // Open file for reading
    if (!file) return 0; // Return 0 if file cannot be opened
    
    char line[256]; // Buffer to store lines from the file
    char train_id[20]; // Buffer for train ID
    int wagon_count; // Variable for number of wagons
    
    // Read train details (ID and wagon count)
    if (fgets(line, sizeof(line), file)) {
        sscanf(line, "TRAIN:%[^:]:%d", train_id, &wagon_count); // Parse train details
        strcpy(train->train_id, train_id); // Copy train ID
    }
    
    // Empty the existing train data
    empty_train(train);
    
    // Read materials section
    int stored_material_count; // Variable for number of materials
    fgets(line, sizeof(line), file); // Skip empty line
    fgets(line, sizeof(line), file); // Read materials header
    sscanf(line, "MATERIALS:%d", &stored_material_count); // Parse material count
    
    for (int i = 0; i < stored_material_count; i++) { // Loop through stored materials
        char name[50]; // Buffer for material name
        float weight; // Material weight
        int quantity, loaded; // Material quantity and loaded amount
        
        fgets(line, sizeof(line), file); // Read material line
        sscanf(line, "M:%[^:]:%f:%d:%d", name, &weight, &quantity, &loaded); // Parse material details
        
        MaterialType* material = find_material_by_name(materials, material_count, name); // Find material
        if (material) { // Update material details if found
            material->quantity = quantity;
            material->loaded = loaded;
        }
    }
    
    // Read wagons section
    while (fgets(line, sizeof(line), file)) { // Loop through remaining lines
        if (line[0] == '\n') continue; // Skip empty lines
        
        if (strncmp(line, "WAGON:", 6) == 0) { // Check if line starts with "WAGON"
            int wagon_id; // Wagon ID
            float max_weight, current_weight; // Wagon weight details
            sscanf(line, "WAGON:%d:%f:%f", &wagon_id, &max_weight, &current_weight); // Parse wagon details
            
            Wagon* wagon = create_wagon(wagon_id, max_weight); // Create a new wagon
            
            // Read loaded materials for the wagon
            while (fgets(line, sizeof(line), file) && line[0] == 'L') { // Loop through loaded materials
                char material_name[50]; // Buffer for material name
                sscanf(line, "L:%[^\n]", material_name); // Parse material name
                
                MaterialType* material = find_material_by_name(materials, material_count, material_name); // Find material
                if (material) {
                    add_material_to_wagon(wagon, material); // Add material to the wagon
                }
            }
            
            // Add wagon to the train
            if (!train->first_wagon) { // If this is the first wagon
                train->first_wagon = wagon;
            } else { // Otherwise, append the wagon to the train
                Wagon* current = train->first_wagon;
                while (current->next) { // Find the last wagon
                    current = current->next;
                }
                current->next = wagon; // Append the new wagon
                wagon->prev = current; // Set the previous wagon link
            }
            train->wagon_count++; // Increment wagon count
        }
    }
    
    fclose(file); // Close the file
    return 1; // Return success
}
