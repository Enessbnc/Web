#include <stdlib.h> 
#include <stdio.h>  
#include "../include/wagon.h" 

// Create and initialize a new wagon
Wagon* create_wagon(int id, float max_weight) {
    Wagon* wagon = malloc(sizeof(Wagon)); // Allocate memory for the wagon
    if (!wagon) return NULL; // Return NULL if memory allocation fails
    
    wagon->wagon_id = id; // Assign wagon ID
    wagon->max_weight = max_weight; // Set maximum weight capacity
    wagon->current_weight = 0; // Initialize current weight to 0
    wagon->loaded_materials = NULL; // Initialize loaded materials list to NULL
    wagon->next = NULL; // Set next wagon pointer to NULL
    wagon->prev = NULL; // Set previous wagon pointer to NULL
    
    return wagon; // Return the newly created wagon
}

// Check if a material can be added to the wagon
int can_add_material(Wagon* wagon, MaterialType* material) {
    // Check if adding the material exceeds weight capacity
    if (wagon->current_weight + material->weight > wagon->max_weight) {
        return 0; // Cannot add material
    }
    
    // If no materials are loaded, the material can be added
    if (!wagon->loaded_materials) {
        return 1; // Material can be added
    }
    
    // Check stacking rules by finding the lightest material in the wagon
    LoadedMaterial* current = wagon->loaded_materials;
    float lightest_current = 999999.0; // Initialize with a large value
    
    while (current) { // Loop through loaded materials
        if (current->type->weight < lightest_current) {
            lightest_current = current->type->weight; // Update the lightest weight
        }
        current = current->next; // Move to the next material
    }
    
    // Ensure heavier items cannot be stacked on lighter ones
    if (material->weight > lightest_current) {
        return 0; // Cannot add material
    }
    
    return 1; // Material can be added
}

// Add material to a wagon
void add_material_to_wagon(Wagon* wagon, MaterialType* material) {
    LoadedMaterial* loaded = malloc(sizeof(LoadedMaterial)); // Allocate memory for loaded material
    if (!loaded) return; // Exit if memory allocation fails
    
    loaded->type = material; // Assign material type
    loaded->next = wagon->loaded_materials; // Insert at the head of the materials list
    loaded->prev = NULL; // Set previous pointer to NULL
    
    if (wagon->loaded_materials) { // If the list is not empty
        wagon->loaded_materials->prev = loaded; // Update the previous pointer of the old head
    }
    wagon->loaded_materials = loaded; // Update the head of the list
    wagon->current_weight += material->weight; // Update the wagon's current weight
}

// Remove material from a wagon
void remove_material_from_wagon(Wagon* wagon, MaterialType* material) {
    LoadedMaterial* current = wagon->loaded_materials; // Start from the head of the materials list
    while (current) { // Loop through the materials
        if (current->type == material) { // If the material matches
            if (current->prev) { // Update the previous material's next pointer
                current->prev->next = current->next;
            } else { // Update the head of the list if this is the first material
                wagon->loaded_materials = current->next;
            }
            if (current->next) { // Update the next material's previous pointer
                current->next->prev = current->prev;
            }
            wagon->current_weight -= material->weight; // Decrease the wagon's weight
            free(current); // Free the memory for the removed material
            break; // Exit the loop
        }
        current = current->next; // Move to the next material
    }
}

// Display the status of a wagon
void display_wagon_status(Wagon* wagon) {
    printf("\nWagon %d Status:\n", wagon->wagon_id); // Display wagon ID
    printf("Current weight: %.2f / %.2f kg\n", wagon->current_weight, wagon->max_weight); // Display weight status
    
    LoadedMaterial* current = wagon->loaded_materials; // Start from the head of the materials list
    while (current) { // Loop through materials
        printf("- %s (%.2f kg)\n", current->type->name, current->type->weight); // Display material details
        current = current->next; // Move to the next material
    }
}

// Free all memory associated with a wagon
void free_wagon(Wagon* wagon) {
    LoadedMaterial* current = wagon->loaded_materials; // Start from the head of the materials list
    while (current) { // Loop through materials
        LoadedMaterial* next = current->next; // Store the next material
        free(current); // Free the current material
        current = next; // Move to the next material
    }
    free(wagon); // Free the wagon itself
}
