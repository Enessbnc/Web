#include <stdlib.h> 
#include <string.h> 
#include <stdio.h> 
#include "../include/train.h" 

// Create and initialize a new train
Train* create_train(const char* id) {
    Train* train = malloc(sizeof(Train)); // Allocate memory for the train
    if (!train) return NULL; // Return NULL if memory allocation fails

    strncpy(train->train_id, id, 19); // Copy train ID (max 19 characters)
    train->train_id[19] = '\0'; // Ensure null-termination
    train->first_wagon = NULL; // Initialize the first wagon pointer
    train->wagon_count = 0; // Initialize wagon count to 0

    return train; // Return the newly created train
}

// Find the first suitable wagon for the given material
static Wagon* find_suitable_wagon(Train* train, MaterialType* material) {
    Wagon* current = train->first_wagon; // Start from the first wagon
    while (current) { // Loop through wagons
        if (can_add_material(current, material)) { // Check if material can be added
            return current; // Return the suitable wagon
        }
        current = current->next; // Move to the next wagon
    }
    return NULL; // Return NULL if no suitable wagon is found
}

// Load material into the train, creating wagons if necessary
void load_material(Train* train, MaterialType* material, int quantity) {
    int loaded = 0; // Track the number of items loaded

    while (quantity > 0) { // While there is material to load
        Wagon* wagon = find_suitable_wagon(train, material); // Find a suitable wagon

        if (!wagon) { // If no suitable wagon is found
            if (train->first_wagon) { // Check if there are any wagons
                Wagon* last = train->first_wagon;
                while (last->next) last = last->next; // Find the last wagon

                // Check stacking rules
                LoadedMaterial* loaded_mat = last->loaded_materials;
                if (loaded_mat && material->weight > loaded_mat->type->weight) {
                    printf("Cannot stack %s (%.2f kg) on wagon with lighter material (%.2f kg)\n", 
                           material->name, material->weight, loaded_mat->type->weight);
                    printf("Creating new wagon for heavier materials...\n");
                }
            }

            // Create a new wagon
            wagon = create_wagon(++train->wagon_count, 1000.0); // New wagon with 1000 kg capacity
            if (!wagon) {
                printf("Failed to create new wagon\n");
                return; // Exit if wagon creation fails
            }

            // Add the new wagon to the train
            if (!train->first_wagon) {
                train->first_wagon = wagon;
            } else {
                Wagon* current = train->first_wagon;
                while (current->next) {
                    current = current->next;
                }
                current->next = wagon;
                wagon->prev = current;
            }
            printf("Created new wagon (ID: %d)\n", wagon->wagon_id);
        }

        // Add material to the wagon
        if (can_add_material(wagon, material)) {
            add_material_to_wagon(wagon, material); // Add material to the wagon
            update_material_quantity(material, 1, 1); // Update material quantity (loading)
            quantity--; // Decrease remaining quantity
            loaded++; // Increment loaded count
            printf("Loaded %s to wagon %d\n", material->name, wagon->wagon_id);
        }
    }

    if (loaded > 0) { // Display loading summary
        if (loaded > 1) {
            printf("Successfully loaded %d %s (distributed across wagons)\n", 
                   loaded, material->name);
        }
    }
}

// Load material into a specific wagon
void load_material_to_wagon(Train* train, int wagon_id, MaterialType* material, int quantity) {
    Wagon* current = train->first_wagon; // Start from the first wagon
    int loaded = 0; // Track the number of items loaded

    // Find the wagon with the specified ID
    while (current && current->wagon_id != wagon_id) {
        current = current->next;
    }

    if (!current) { // If the wagon is not found
        printf("Wagon %d not found\n", wagon_id);
        return;
    }

    // Check stacking and weight rules
    if (!can_add_material(current, material)) {
        printf("Cannot load %s to wagon %d due to stacking rules or weight restrictions\n", 
               material->name, wagon_id);
        return;
    }

    // Load material into the wagon
    while (quantity > 0 && can_add_material(current, material)) {
        add_material_to_wagon(current, material); // Add material
        update_material_quantity(material, 1, 1); // Update material quantity
        quantity--; // Decrease remaining quantity
        loaded++; // Increment loaded count
    }

    if (quantity > 0) { // If not all material could be loaded
        printf("Could only load %d out of %d %s to wagon %d\n", 
               loaded, loaded + quantity, material->name, wagon_id);
    }
}

// Unload material from a specific wagon
void unload_material_from_wagon(Train* train, int wagon_id, MaterialType* material, int quantity) {
    Wagon* current = train->first_wagon; // Start from the first wagon

    // Find the wagon with the specified ID
    while (current && current->wagon_id != wagon_id) {
        current = current->next;
    }

    if (!current) { // If the wagon is not found
        printf("Wagon %d not found\n", wagon_id);
        return;
    }

    // Count how many of this material are in the wagon
    int available = 0;
    LoadedMaterial* loaded = current->loaded_materials;
    while (loaded) {
        if (loaded->type == material) available++;
        loaded = loaded->next;
    }

    // Adjust quantity if necessary
    if (quantity > available) {
        quantity = available;
    }

    // Unload the materials
    while (quantity > 0) {
        remove_material_from_wagon(current, material); // Remove material from wagon
        update_material_quantity(material, 1, 0); // Update material quantity (unloading)
        quantity--; // Decrease remaining quantity
    }

    // Remove wagon if empty
    if (current->current_weight == 0) {
        if (current->prev) {
            current->prev->next = current->next;
        } else {
            train->first_wagon = current->next;
        }
        if (current->next) {
            current->next->prev = current->prev;
        }
        free_wagon(current); // Free wagon memory
        train->wagon_count--; // Decrement wagon count
    }
}

// Unload material from the train
void unload_material(Train* train, MaterialType* material, int quantity) {
    if (!train || !material || quantity <= 0) return; // Validate inputs

    int unloaded = 0; // Track the number of items unloaded
    Wagon* current = train->first_wagon; // Start from the first wagon

    while (current && quantity > 0) { // Loop through wagons
        // Count how many of this material type are in the current wagon
        int wagon_count = 0;
        LoadedMaterial* counter = current->loaded_materials;
        while (counter) {
            if (counter->type == material) wagon_count++;
            counter = counter->next;
        }

        // Unload up to 'quantity' items from this wagon
        int to_unload = (wagon_count < quantity) ? wagon_count : quantity;
        for (int i = 0; i < to_unload; i++) {
            remove_material_from_wagon(current, material); // Remove material
            update_material_quantity(material, 1, 0); // Update material quantity
            unloaded++; // Increment unloaded count
            quantity--; // Decrease remaining quantity
        }

        // Store next wagon pointer before potentially freeing current wagon
        Wagon* next = current->next;

        // Remove wagon if empty
        if (current->current_weight == 0) {
            if (current->prev) {
                current->prev->next = current->next;
            } else {
                train->first_wagon = current->next;
            }
            if (current->next) {
                current->next->prev = current->prev;
            }
            free_wagon(current); // Free wagon memory
            train->wagon_count--; // Decrement wagon count
        }

        current = next; // Move to the next wagon
    }

    if (unloaded > 0) { // Display unloading summary
        printf("Successfully unloaded %d %s\n", unloaded, material->name);
    }
    if (quantity > 0) { // If not all material could be unloaded
        printf("Could not unload %d %s (not found on train)\n", 
               quantity, material->name);
    }
}

// Display the status of the train
void display_train_status(Train* train) {
    printf("\n=== Train %s Status ===\n", train->train_id);
    printf("Number of wagons: %d\n", train->wagon_count);

    Wagon* current = train->first_wagon; // Start from the first wagon
    while (current) { // Loop through wagons
        display_wagon_status(current); // Display status of each wagon
        current = current->next; // Move to the next wagon
    }
}

// Empty all wagons in the train
void empty_train(Train* train) {
    while (train->first_wagon) { // Loop until all wagons are removed
        Wagon* next = train->first_wagon->next; // Store the next wagon
        free_wagon(train->first_wagon); // Free current wagon memory
        train->first_wagon = next; // Move to the next wagon
    }
    train->wagon_count = 0; // Reset wagon count
}

// Free all train-related resources
void free_train(Train* train) {
    empty_train(train); // Empty the train
    free(train); // Free train memory
}
