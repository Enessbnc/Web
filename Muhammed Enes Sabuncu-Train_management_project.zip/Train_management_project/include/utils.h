// include/utils.h
#ifndef UTILS_H
#define UTILS_H

#include "train.h"
#include "material.h"

// Utility function declarations
void clear_input_buffer(void);
MaterialType* find_material_by_name(MaterialType** materials, int count, const char* name);
int validate_quantity(int requested, int available);
void renumber_wagons(Train* train);
char* trim_string(char* str);

#endif