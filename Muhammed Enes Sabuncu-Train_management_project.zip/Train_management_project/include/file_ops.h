// include/file_ops.h
#ifndef FILE_OPS_H
#define FILE_OPS_H

#include "train.h"
#include "material.h"

// File operations function declarations
int save_train_status(const char* filename, Train* train, MaterialType** materials, int material_count);
int load_train_status(const char* filename, Train* train, MaterialType** materials, int material_count);

#endif