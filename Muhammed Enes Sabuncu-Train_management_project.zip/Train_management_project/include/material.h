#ifndef MATERIAL_H
#define MATERIAL_H

typedef struct {
    char name[50];
    float weight;
    int quantity;
    int loaded;
} MaterialType;

typedef struct LoadedMaterial {
    MaterialType* type;
    struct LoadedMaterial *next, *prev;
} LoadedMaterial;

MaterialType* create_material(const char* name, float weight, int quantity);
void update_material_quantity(MaterialType* material, int change, int is_loading);
void display_materials_status(MaterialType** materials, int count);

#endif