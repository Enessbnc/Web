#ifndef TRAIN_H
#define TRAIN_H

#include "wagon.h"

typedef struct {
    char train_id[20];
    Wagon* first_wagon;
    int wagon_count;
} Train;

Train* create_train(const char* id);
void load_material(Train* train, MaterialType* material, int quantity);
void load_material_to_wagon(Train* train, int wagon_id, MaterialType* material, int quantity);
void unload_material(Train* train, MaterialType* material, int quantity);
void unload_material_from_wagon(Train* train, int wagon_id, MaterialType* material, int quantity);
void display_train_status(Train* train);
void empty_train(Train* train);
void free_train(Train* train);

#endif