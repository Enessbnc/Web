// wagon.h
#ifndef WAGON_H
#define WAGON_H

#include "material.h"

typedef struct Wagon {
    int wagon_id;
    float max_weight;
    float current_weight;
    LoadedMaterial* loaded_materials;
    struct Wagon *next, *prev;
} Wagon;


Wagon* create_wagon(int id, float max_weight);

int can_add_material(Wagon* wagon, MaterialType* material);

void add_material_to_wagon(Wagon* wagon, MaterialType* material);

void remove_material_from_wagon(Wagon* wagon, MaterialType* material);

void display_wagon_status(Wagon* wagon);

void free_wagon(Wagon* wagon);

#endif